DROP FUNCTION kmeans(float[], int);
DROP FUNCTION kmeans(float[], int, float[]);
