kmeans-postgresql
=================

This module implements k-means clustering algorithm in
PostgreSQL. It is a truely user-defined window function out of
builtin functions, written in C.

Designed for PostgreSQL 8.4+

Hitoshi Harada
